import app from '../src/server/apiApp';

// Vercel Serverless Function entry point for all /api routes
export default app;
