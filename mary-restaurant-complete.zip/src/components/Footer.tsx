import React from 'react';
import { Phone, Mail, MapPin, Clock, ShieldCheck, Heart } from 'lucide-react';
import { PageRoute } from '../types';
import { useCart } from '../context/CartContext';

interface FooterProps {
  setCurrentPage: (page: PageRoute) => void;
}

export const Footer: React.FC<FooterProps> = ({ setCurrentPage }) => {
  const { settings } = useCart();

  const handleNavClick = (page: PageRoute) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const whatsappPhone = settings?.whatsapp_number || '2349024971419';
  const displayPhone = settings?.phone_display || '09024971419';

  return (
    <footer className="bg-stone-950 text-stone-300 pt-16 pb-12 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Col 1: Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-red-700 text-white rounded-xl flex items-center justify-center font-serif font-black text-2xl shadow">
                M
              </div>
              <div>
                <span className="block text-xl font-extrabold tracking-tight text-white font-serif">
                  MARY RESTAURANT
                </span>
                <span className="block text-xs font-semibold text-red-500 tracking-wider uppercase">
                  Authentic Nigerian Cuisine
                </span>
              </div>
            </div>

            <p className="text-sm text-stone-400 leading-relaxed">
              Serving mouth-watering, authentic Nigerian meals cooked with fresh local ingredients, 
              rich traditional spices, and genuine passion. Fast delivery across Lagos.
            </p>

            <div className="flex items-center gap-2 text-xs text-stone-400">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>100% Fresh Daily Preparation & Hygienic Packaging</span>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div>
            <h4 className="text-white font-bold text-sm tracking-wider uppercase mb-4 font-serif">
              Explore Menu
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button
                  onClick={() => handleNavClick('menu')}
                  className="hover:text-white transition-colors text-stone-400 hover:translate-x-1 inline-block"
                >
                  Party Jollof & Fried Rice
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNavClick('menu')}
                  className="hover:text-white transition-colors text-stone-400 hover:translate-x-1 inline-block"
                >
                  Native Soups & Fresh Swallows
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNavClick('menu')}
                  className="hover:text-white transition-colors text-stone-400 hover:translate-x-1 inline-block"
                >
                  Flame-Grilled & Peppered Chicken
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNavClick('menu')}
                  className="hover:text-white transition-colors text-stone-400 hover:translate-x-1 inline-block"
                >
                  Special Moi Moi & Golden Dodo
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNavClick('menu')}
                  className="hover:text-white transition-colors text-stone-400 hover:translate-x-1 inline-block"
                >
                  Chilled Chapman & Cold Drinks
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Contact & Hours */}
          <div>
            <h4 className="text-white font-bold text-sm tracking-wider uppercase mb-4 font-serif">
              Restaurant Details
            </h4>
            <ul className="space-y-3 text-sm text-stone-400">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <span>{settings?.physical_address || '14 Adeola Odeku Street, Victoria Island, Lagos, Nigeria'}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-red-500 shrink-0" />
                <a
                  href={`https://wa.me/${whatsappPhone}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors"
                >
                  {displayPhone} (WhatsApp & Calls)
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-red-500 shrink-0" />
                <span>{settings?.email_contact || 'orders@maryrestaurant.ng'}</span>
              </li>
              <li className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <span>{settings?.opening_hours || 'Monday - Sunday: 8:00 AM - 10:00 PM'}</span>
              </li>
            </ul>
          </div>

          {/* Col 4: Payment & WhatsApp Order */}
          <div className="space-y-4">
            <h4 className="text-white font-bold text-sm tracking-wider uppercase mb-2 font-serif">
              Instant Ordering
            </h4>
            <p className="text-xs text-stone-400 leading-relaxed">
              Order directly through our website or chat with our kitchen dispatch on WhatsApp.
            </p>
            <a
              href={`https://wa.me/${whatsappPhone}?text=${encodeURIComponent('Hello Mary Restaurant, I would like to make an order.')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-2.5 px-4 rounded-xl text-sm transition-colors shadow-sm"
            >
              <Phone className="w-4 h-4" />
              <span>Chat on WhatsApp ({displayPhone})</span>
            </a>

            <div className="pt-2 border-t border-stone-800">
              <span className="block text-xs font-medium text-stone-400 mb-1.5">
                Accepted Payment Channels
              </span>
              <div className="flex flex-wrap gap-2 text-[11px] text-stone-400">
                <span className="bg-stone-900 border border-stone-800 px-2 py-1 rounded">Bank Transfer</span>
                <span className="bg-stone-900 border border-stone-800 px-2 py-1 rounded">Paystack</span>
                <span className="bg-stone-900 border border-stone-800 px-2 py-1 rounded">Cards / USSD</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-stone-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500">
          <p>© {new Date().getFullYear()} MARY RESTAURANT. All rights reserved. Handcrafted with pride.</p>
          <div className="flex items-center gap-6">
            <button
              onClick={() => handleNavClick('about')}
              className="hover:text-stone-300 transition-colors"
            >
              About Us
            </button>
            <button
              onClick={() => handleNavClick('contact')}
              className="hover:text-stone-300 transition-colors"
            >
              Contact Us
            </button>
            <button
              onClick={() => handleNavClick('privacy')}
              className="hover:text-stone-300 transition-colors"
            >
              Privacy Policy
            </button>
            <button
              onClick={() => handleNavClick('admin-login')}
              className="hover:text-red-400 transition-colors font-medium"
            >
              Admin Portal
            </button>
            <a
              href="/mary-restaurant-complete.zip"
              download="mary-restaurant-complete.zip"
              className="hover:text-amber-400 transition-colors font-bold flex items-center gap-1 text-stone-300"
              title="Download Complete Source Code ZIP"
            >
              <span>Download Website (.ZIP)</span>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
