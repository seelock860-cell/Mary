import React from 'react';
import { Plus, Check, Eye } from 'lucide-react';
import { Product } from '../types';
import { useCart } from '../context/CartContext';

interface FoodCardProps {
  product: Product;
  categoryName?: string;
  onSelect: (product: Product) => void;
}

export const FoodCard: React.FC<FoodCardProps> = ({ product, categoryName, onSelect }) => {
  const { addToCart, formatNaira, cart } = useCart();

  const cartItem = cart.find((i) => i.product.id === product.id);
  const currentQuantityInCart = cartItem ? cartItem.quantity : 0;

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!product.is_available) return;
    addToCart(product, 1);
  };

  return (
    <article
      onClick={() => onSelect(product)}
      className="group relative bg-white rounded-2xl overflow-hidden border border-stone-200/80 hover:border-red-300 hover:shadow-xl transition-all duration-300 cursor-pointer flex flex-col"
    >
      {/* Image Container */}
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-stone-100">
        <img
          src={product.image_url}
          alt={product.name}
          loading="lazy"
          className={`w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 ${
            !product.is_available ? 'grayscale opacity-60' : ''
          }`}
          onError={(e) => {
            // High reliability fallback
            (e.target as HTMLImageElement).src =
              'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80';
          }}
        />

        {/* Quiet status or count badge */}
        {!product.is_available ? (
          <div className="absolute inset-0 bg-stone-900/60 backdrop-blur-[2px] flex items-center justify-center">
            <span className="text-white text-xs font-bold tracking-wider uppercase px-3 py-1 bg-stone-900/90 rounded-md">
              Sold Out Today
            </span>
          </div>
        ) : (
          <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
            <span className="bg-white/90 backdrop-blur-sm text-stone-700 hover:text-red-700 p-2 rounded-xl shadow flex items-center gap-1 text-xs font-semibold">
              <Eye className="w-3.5 h-3.5" />
              Quick View
            </span>
          </div>
        )}

        {currentQuantityInCart > 0 && product.is_available && (
          <div className="absolute top-3 left-3 bg-red-700 text-white text-xs font-bold px-2.5 py-1 rounded-md shadow">
            {currentQuantityInCart} in cart
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-5 flex flex-col flex-grow justify-between">
        <div>
          {/* Metadata line without pill enclosure */}
          <div className="flex items-center gap-2 text-xs font-medium text-stone-500 mb-1.5">
            <span>{categoryName || 'Nigerian Special'}</span>
            <span aria-hidden="true">·</span>
            <span>Made Fresh</span>
          </div>

          <h3 className="text-base sm:text-lg font-bold text-stone-900 group-hover:text-red-700 transition-colors line-clamp-1 font-serif">
            {product.name}
          </h3>

          <p className="mt-1.5 text-xs sm:text-sm text-stone-600 line-clamp-2 leading-relaxed">
            {product.description}
          </p>
        </div>

        {/* Footer: Price and Add Button */}
        <div className="mt-5 pt-4 border-t border-stone-100 flex items-center justify-between">
          <div>
            <span className="block text-[11px] text-stone-500 uppercase tracking-wider font-medium">Price</span>
            <span className="text-lg font-extrabold text-stone-900">
              {formatNaira(product.price)}
            </span>
          </div>

          <button
            type="button"
            onClick={handleQuickAdd}
            disabled={!product.is_available}
            className={`flex items-center gap-1.5 py-2 px-4 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              !product.is_available
                ? 'bg-stone-100 text-stone-400 cursor-not-allowed'
                : currentQuantityInCart > 0
                ? 'bg-red-50 text-red-700 border border-red-200 hover:bg-red-100'
                : 'bg-red-700 hover:bg-red-800 text-white shadow-sm hover:shadow active:scale-95'
            }`}
          >
            {currentQuantityInCart > 0 ? (
              <>
                <Check className="w-4 h-4" />
                <span>Add More</span>
              </>
            ) : (
              <>
                <Plus className="w-4 h-4" />
                <span>Add to Cart</span>
              </>
            )}
          </button>
        </div>
      </div>
    </article>
  );
};
