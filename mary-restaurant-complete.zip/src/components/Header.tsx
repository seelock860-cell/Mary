import React, { useState } from 'react';
import { ShoppingBag, Phone, Menu, X, Shield, Clock } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { PageRoute } from '../types';

interface HeaderProps {
  currentPage: PageRoute;
  setCurrentPage: (page: PageRoute) => void;
}

export const Header: React.FC<HeaderProps> = ({ currentPage, setCurrentPage }) => {
  const { totalCount, settings } = useCart();
  const { isAdminAuthenticated } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks: { label: string; page: PageRoute }[] = [
    { label: 'Home', page: 'home' },
    { label: 'Food Menu', page: 'menu' },
    { label: 'About Us', page: 'about' },
    { label: 'Contact', page: 'contact' },
  ];

  const handleNavClick = (page: PageRoute) => {
    setCurrentPage(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const whatsappPhone = settings?.whatsapp_number || '2349024971419';
  const displayPhone = settings?.phone_display || '09024971419';

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200 transition-all">
      {/* Top Announcement Bar */}
      <div className="bg-stone-900 text-stone-200 text-xs py-1.5 px-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-red-400 font-medium">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              Kitchen Open
            </span>
            <span className="hidden sm:inline text-stone-400" aria-hidden="true">·</span>
            <span className="hidden sm:inline text-stone-300">
              Fresh Hot Nigerian Dishes Made to Order
            </span>
            <span className="hidden md:inline text-stone-400" aria-hidden="true">·</span>
            <span className="hidden md:inline text-stone-400 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              {settings?.opening_hours || '8:00 AM - 10:00 PM Daily'}
            </span>
          </div>

          <div className="flex items-center gap-4">
            <a
              href={`https://wa.me/${whatsappPhone}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-stone-300 hover:text-white transition-colors flex items-center gap-1"
            >
              <Phone className="w-3 h-3 text-red-400" />
              <span>WhatsApp: {displayPhone}</span>
            </a>
            <span className="text-stone-600" aria-hidden="true">|</span>
            <button
              onClick={() => handleNavClick(isAdminAuthenticated ? 'admin-dashboard' : 'admin-login')}
              className="text-stone-400 hover:text-stone-200 transition-colors flex items-center gap-1"
              title="Admin Portal"
            >
              <Shield className="w-3 h-3" />
              <span className="text-[11px] font-medium">{isAdminAuthenticated ? 'Admin Panel' : 'Admin'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Brand Logo */}
          <button
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 text-left group focus:outline-none focus-visible:ring-2 focus-visible:ring-red-600 rounded-lg p-1"
          >
            <div className="w-11 h-11 bg-red-700 text-white rounded-xl flex items-center justify-center font-serif font-black text-2xl shadow-md group-hover:bg-red-800 transition-colors">
              M
            </div>
            <div>
              <span className="block text-xl font-extrabold tracking-tight text-stone-900 group-hover:text-red-700 transition-colors leading-none font-serif">
                MARY RESTAURANT
              </span>
              <span className="block text-[11px] font-semibold text-red-600 tracking-wider uppercase mt-1">
                Authentic Nigerian Delicacies
              </span>
            </div>
          </button>

          {/* Desktop Links */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => {
              const isActive = currentPage === link.page;
              return (
                <button
                  key={link.page}
                  onClick={() => handleNavClick(link.page)}
                  className={`relative py-1 text-sm font-semibold transition-colors focus:outline-none ${
                    isActive
                      ? 'text-red-700'
                      : 'text-stone-700 hover:text-red-700'
                  }`}
                >
                  {link.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-red-600 rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Action Area: Cart & Order CTA */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => handleNavClick('cart')}
              className="relative p-2.5 text-stone-800 hover:text-red-700 hover:bg-stone-100 rounded-xl transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-red-600"
              aria-label="View Shopping Cart"
            >
              <ShoppingBag className="w-6 h-6" />
              {totalCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-600 text-white font-bold text-xs w-5 h-5 rounded-full flex items-center justify-center shadow-sm animate-scale">
                  {totalCount}
                </span>
              )}
            </button>

            <button
              onClick={() => handleNavClick('menu')}
              className="hidden sm:inline-flex items-center justify-center bg-red-700 hover:bg-red-800 text-white font-semibold text-sm px-5 py-2.5 rounded-xl shadow-sm transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-red-600 focus-visible:ring-offset-2"
            >
              Order Now
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-stone-700 hover:text-stone-900 rounded-lg hover:bg-stone-100 transition-colors"
              aria-label="Toggle Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-stone-200 px-4 pt-3 pb-6 space-y-3 shadow-xl animate-fadeIn">
          <div className="flex flex-col space-y-1">
            {navLinks.map((link) => (
              <button
                key={link.page}
                onClick={() => handleNavClick(link.page)}
                className={`text-left px-3 py-2.5 rounded-lg text-base font-semibold transition-colors ${
                  currentPage === link.page
                    ? 'bg-red-50 text-red-700 font-bold'
                    : 'text-stone-800 hover:bg-stone-50'
                }`}
              >
                {link.label}
              </button>
            ))}
            <button
              onClick={() => handleNavClick('cart')}
              className="text-left px-3 py-2.5 rounded-lg text-base font-semibold text-stone-800 hover:bg-stone-50 flex items-center justify-between"
            >
              <span>Shopping Cart</span>
              <span className="bg-red-100 text-red-700 text-xs px-2 py-0.5 rounded-md font-bold">
                {totalCount} items
              </span>
            </button>
            <button
              onClick={() => handleNavClick(isAdminAuthenticated ? 'admin-dashboard' : 'admin-login')}
              className="text-left px-3 py-2.5 rounded-lg text-sm text-stone-500 hover:bg-stone-50 flex items-center gap-2"
            >
              <Shield className="w-4 h-4 text-stone-400" />
              <span>{isAdminAuthenticated ? 'Administrator Dashboard' : 'Admin Login'}</span>
            </button>
          </div>

          <div className="pt-2">
            <button
              onClick={() => handleNavClick('menu')}
              className="w-full bg-red-700 text-white font-semibold py-3 px-4 rounded-xl text-center shadow-sm"
            >
              Explore Full Nigerian Menu
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
