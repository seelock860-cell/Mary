import React, { useState } from 'react';
import { X, Plus, Minus, ShoppingBag, Phone, Check, Sparkles } from 'lucide-react';
import { Product, Category } from '../types';
import { useCart } from '../context/CartContext';

interface FoodDetailModalProps {
  product: Product | null;
  categories: Category[];
  onClose: () => void;
}

export const FoodDetailModal: React.FC<FoodDetailModalProps> = ({ product, categories, onClose }) => {
  const { addToCart, formatNaira, settings } = useCart();
  const [quantity, setQuantity] = useState(1);

  if (!product) return null;

  const category = categories.find((c) => c.id === product.category_id);
  const whatsappPhone = settings?.whatsapp_number || '2349024971419';

  const handleAddToCart = () => {
    addToCart(product, quantity);
    onClose();
  };

  const whatsappMessage = encodeURIComponent(
    `Hello Mary Restaurant! I'm interested in ordering "${product.name}" (${formatNaira(product.price)}). Can I get more details on preparation time?`
  );

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
      <div
        className="relative bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-stone-200 animate-scaleUp"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2.5 rounded-full bg-white/90 hover:bg-white text-stone-700 hover:text-stone-900 shadow-md transition-colors"
          aria-label="Close food details"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 sm:grid-cols-2">
          {/* Photograph */}
          <div className="relative h-64 sm:h-full min-h-[280px] bg-stone-100">
            <img
              src={product.image_url}
              alt={product.name}
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src =
                  'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80';
              }}
            />
            {!product.is_available && (
              <div className="absolute inset-0 bg-stone-950/70 flex items-center justify-center">
                <span className="text-white text-sm font-bold uppercase tracking-wider px-3 py-1 bg-red-600 rounded">
                  Sold Out
                </span>
              </div>
            )}
          </div>

          {/* Details Content */}
          <div className="p-6 sm:p-8 flex flex-col justify-between">
            <div>
              {/* Unboxed Metadata */}
              <div className="flex items-center gap-2 text-xs font-semibold text-stone-500 mb-2">
                <span>{category?.name || 'Nigerian Cuisine'}</span>
                <span aria-hidden="true">·</span>
                <span className={product.is_available ? 'text-emerald-700' : 'text-red-600'}>
                  {product.is_available ? 'Available Now' : 'Currently Unavailable'}
                </span>
              </div>

              <h2 className="text-xl sm:text-2xl font-bold text-stone-900 font-serif leading-snug">
                {product.name}
              </h2>

              <p className="mt-3 text-sm text-stone-600 leading-relaxed">
                {product.description}
              </p>

              {/* Culinary highlights */}
              <div className="mt-5 pt-4 border-t border-stone-100 space-y-2 text-xs text-stone-500">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>Prepared with 100% genuine local Nigerian condiments</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Freshly cooked hot and packed in secure food-grade containers</span>
                </div>
              </div>
            </div>

            {/* Price & Quantity & Actions */}
            <div className="mt-6 pt-5 border-t border-stone-100">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <span className="block text-xs text-stone-500 uppercase tracking-wider">Total</span>
                  <span className="text-2xl font-black text-stone-950">
                    {formatNaira(product.price * quantity)}
                  </span>
                </div>

                {/* Quantity Controls */}
                <div className="flex items-center border border-stone-300 rounded-xl bg-stone-50 overflow-hidden">
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    disabled={quantity <= 1 || !product.is_available}
                    className="p-2 hover:bg-stone-200 text-stone-700 disabled:opacity-40 transition-colors"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="px-3 text-sm font-bold text-stone-900">
                    {quantity}
                  </span>
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => q + 1)}
                    disabled={!product.is_available}
                    className="p-2 hover:bg-stone-200 text-stone-700 disabled:opacity-40 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <button
                  type="button"
                  onClick={handleAddToCart}
                  disabled={!product.is_available}
                  className="w-full bg-red-700 hover:bg-red-800 disabled:bg-stone-200 disabled:text-stone-400 text-white font-semibold py-3 px-4 rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>{product.is_available ? 'Add to My Cart' : 'Currently Unavailable'}</span>
                </button>

                <a
                  href={`https://wa.me/${whatsappPhone}?text=${whatsappMessage}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 font-semibold py-2.5 px-4 rounded-xl transition-all flex items-center justify-center gap-2 text-xs"
                >
                  <Phone className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Ask Mary Kitchen on WhatsApp</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
