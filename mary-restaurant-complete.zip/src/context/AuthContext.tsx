import React, { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../services/api';

interface AdminUser {
  username: string;
  role: string;
  full_name: string;
}

interface AuthContextType {
  adminUser: AdminUser | null;
  adminToken: string | null;
  isAdminAuthenticated: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  authError: string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [adminUser, setAdminUser] = useState<AdminUser | null>(() => {
    try {
      const saved = localStorage.getItem('mary_restaurant_admin_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [adminToken, setAdminToken] = useState<string | null>(() => {
    try {
      return localStorage.getItem('mary_restaurant_admin_token');
    } catch {
      return null;
    }
  });

  const [authError, setAuthError] = useState<string | null>(null);

  useEffect(() => {
    if (adminUser && adminToken) {
      localStorage.setItem('mary_restaurant_admin_user', JSON.stringify(adminUser));
      localStorage.setItem('mary_restaurant_admin_token', adminToken);
    } else {
      localStorage.removeItem('mary_restaurant_admin_user');
      localStorage.removeItem('mary_restaurant_admin_token');
    }
  }, [adminUser, adminToken]);

  const login = async (username: string, password: string): Promise<boolean> => {
    setAuthError(null);
    try {
      const res = await api.adminLogin(username, password);
      if (res.success && res.user) {
        setAdminUser(res.user);
        setAdminToken(res.token);
        return true;
      }
      setAuthError('Authentication failed');
      return false;
    } catch (err: any) {
      setAuthError(err.message || 'Login failed. Please verify username and password.');
      return false;
    }
  };

  const logout = () => {
    setAdminUser(null);
    setAdminToken(null);
    setAuthError(null);
  };

  return (
    <AuthContext.Provider
      value={{
        adminUser,
        adminToken,
        isAdminAuthenticated: !!adminUser,
        login,
        logout,
        authError,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
