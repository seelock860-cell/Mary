/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Product, Category, PageRoute, Order } from './types';
import { INITIAL_PRODUCTS, INITIAL_CATEGORIES } from './data/initialData';
import { api } from './services/api';
import { CartProvider, useCart } from './context/CartContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { WhatsAppFloatingButton } from './components/WhatsAppFloatingButton';
import { FoodDetailModal } from './components/FoodDetailModal';
import { Toast } from './components/Toast';

// Pages
import { HomePage } from './pages/HomePage';
import { MenuPage } from './pages/MenuPage';
import { CartPage } from './pages/CartPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { OrderConfirmationPage } from './pages/OrderConfirmationPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { PrivacyPage } from './pages/PrivacyPage';
import { AdminLoginPage } from './pages/AdminLoginPage';
import { AdminDashboardPage } from './pages/AdminDashboardPage';

function RestaurantApp() {
  const [currentPage, setCurrentPage] = useState<PageRoute>('home');
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [categories, setCategories] = useState<Category[]>(INITIAL_CATEGORIES);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);

  const { setSettings } = useCart();
  const { isAdminAuthenticated } = useAuth();

  // Load menu and settings from backend
  const loadInitialData = async () => {
    try {
      const menuData = await api.getMenu();
      if (menuData.products && menuData.products.length > 0) {
        setProducts(menuData.products);
      }
      if (menuData.categories && menuData.categories.length > 0) {
        setCategories(menuData.categories);
      }
    } catch {
      // Use bundled initial data on network or startup delay
    }

    try {
      const settingsData = await api.getSettings();
      if (settingsData) {
        setSettings(settingsData);
      }
    } catch {
      // Fallback
    }
  };

  useEffect(() => {
    loadInitialData();
  }, []);

  const handleSelectProduct = (product: Product) => {
    setSelectedProduct(product);
  };

  const isAdminView = currentPage === 'admin-dashboard';

  return (
    <div className="min-h-screen flex flex-col bg-[#faf7f2] text-stone-900 selection:bg-red-700 selection:text-white">
      {/* Customer Header (only when not on full admin dashboard) */}
      {!isAdminView && (
        <Header currentPage={currentPage} setCurrentPage={setCurrentPage} />
      )}

      {/* Main Page Content */}
      <main className="flex-grow">
        {currentPage === 'home' && (
          <HomePage
            products={products}
            categories={categories}
            setCurrentPage={setCurrentPage}
            onSelectProduct={handleSelectProduct}
            setSelectedCategory={setSelectedCategory}
          />
        )}

        {currentPage === 'menu' && (
          <MenuPage
            products={products}
            categories={categories}
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
            onSelectProduct={handleSelectProduct}
          />
        )}

        {currentPage === 'cart' && (
          <CartPage setCurrentPage={setCurrentPage} />
        )}

        {currentPage === 'checkout' && (
          <CheckoutPage
            setCurrentPage={setCurrentPage}
            setConfirmedOrder={setConfirmedOrder}
          />
        )}

        {currentPage === 'order-confirmation' && (
          <OrderConfirmationPage
            order={confirmedOrder}
            setCurrentPage={setCurrentPage}
          />
        )}

        {currentPage === 'about' && (
          <AboutPage setCurrentPage={setCurrentPage} />
        )}

        {currentPage === 'contact' && (
          <ContactPage />
        )}

        {currentPage === 'privacy' && (
          <PrivacyPage />
        )}

        {currentPage === 'admin-login' && (
          <AdminLoginPage setCurrentPage={setCurrentPage} />
        )}

        {currentPage === 'admin-dashboard' && (
          isAdminAuthenticated ? (
            <AdminDashboardPage
              products={products}
              categories={categories}
              onRefreshMenu={loadInitialData}
              setCurrentPage={setCurrentPage}
            />
          ) : (
            <AdminLoginPage setCurrentPage={setCurrentPage} />
          )
        )}
      </main>

      {/* Modal for Food Details */}
      {selectedProduct && (
        <FoodDetailModal
          product={selectedProduct}
          categories={categories}
          onClose={() => setSelectedProduct(null)}
        />
      )}

      {/* Toast Notification Container */}
      <Toast />

      {/* WhatsApp Quick Chat Button on public pages */}
      {!isAdminView && <WhatsAppFloatingButton />}

      {/* Footer on public pages */}
      {!isAdminView && <Footer setCurrentPage={setCurrentPage} />}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <RestaurantApp />
      </CartProvider>
    </AuthProvider>
  );
}
