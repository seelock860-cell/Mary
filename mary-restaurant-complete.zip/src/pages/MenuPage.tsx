import React, { useState, useMemo } from 'react';
import { Search, SlidersHorizontal, Utensils, AlertCircle } from 'lucide-react';
import { Product, Category } from '../types';
import { FoodCard } from '../components/FoodCard';

interface MenuPageProps {
  products: Product[];
  categories: Category[];
  selectedCategory: string;
  setSelectedCategory: (catId: string) => void;
  onSelectProduct: (product: Product) => void;
}

export const MenuPage: React.FC<MenuPageProps> = ({
  products,
  categories,
  selectedCategory,
  setSelectedCategory,
  onSelectProduct,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      const matchesCategory =
        selectedCategory === 'all' || product.category_id === selectedCategory;
      const matchesSearch =
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [products, selectedCategory, searchQuery]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      {/* Page Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-bold uppercase tracking-wider text-red-700">
          Fresh Daily Menu
        </span>
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-stone-950 font-serif">
          Authentic Nigerian Delicacies
        </h1>
        <p className="text-sm sm:text-base text-stone-600 leading-relaxed">
          From fiery party jollof rice and rich native soups to fresh swallows, 
          flame-grilled proteins, and chilled refreshments. All prepared with genuine local spices.
        </p>
      </div>

      {/* Search and Category Filter Toolbar */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-stone-200/80 shadow-sm space-y-4">
        {/* Search Input */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by meal name or ingredients (e.g. Jollof, Egusi, Amala, Chicken...)"
            className="w-full pl-12 pr-4 py-3 bg-stone-50 border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-red-600 focus:bg-white transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-stone-400 hover:text-stone-700 font-semibold"
            >
              Clear
            </button>
          )}
        </div>

        {/* Functional Category Filter Buttons */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <button
            type="button"
            onClick={() => setSelectedCategory('all')}
            className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-xl whitespace-nowrap transition-all ${
              selectedCategory === 'all'
                ? 'bg-red-700 text-white shadow-sm'
                : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
            }`}
          >
            All Dishes ({products.length})
          </button>

          {categories.map((cat) => {
            const count = products.filter((p) => p.category_id === cat.id).length;
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-xl whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-red-700 text-white shadow-sm'
                    : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                }`}
              >
                {cat.name} ({count})
              </button>
            );
          })}
        </div>
      </div>

      {/* Results Count & Meta info */}
      <div className="flex items-center justify-between text-xs text-stone-500 px-1">
        <span>
          Showing <strong className="text-stone-900">{filteredProducts.length}</strong> items
          {selectedCategory !== 'all' && (
            <span>
              {' '}in{' '}
              <strong className="text-stone-900">
                {categories.find((c) => c.id === selectedCategory)?.name}
              </strong>
            </span>
          )}
        </span>
        <span>All prices in Nigerian Naira (₦)</span>
      </div>

      {/* Menu Grid */}
      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => {
            const category = categories.find((c) => c.id === product.category_id);
            return (
              <FoodCard
                key={product.id}
                product={product}
                categoryName={category?.name}
                onSelect={onSelectProduct}
              />
            );
          })}
        </div>
      ) : (
        <div className="text-center py-16 bg-white rounded-3xl border border-stone-200 p-8 space-y-4">
          <div className="w-16 h-16 bg-stone-100 text-stone-400 rounded-full flex items-center justify-center mx-auto">
            <Utensils className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-stone-900 font-serif">
            No dishes found
          </h3>
          <p className="text-xs sm:text-sm text-stone-500 max-w-sm mx-auto">
            We couldn't find any meal matching "{searchQuery}". Try searching for Jollof, Egusi, or Swallows.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('all');
            }}
            className="inline-flex items-center gap-2 text-xs font-bold text-red-700 hover:text-red-800 underline"
          >
            Reset Filters
          </button>
        </div>
      )}
    </div>
  );
};
