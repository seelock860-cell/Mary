import React from 'react';
import { 
  ShoppingBag, 
  Trash2, 
  Plus, 
  Minus, 
  ArrowRight, 
  Truck, 
  Store, 
  AlertCircle,
  ShieldCheck
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { PageRoute } from '../types';

interface CartPageProps {
  setCurrentPage: (page: PageRoute) => void;
}

export const CartPage: React.FC<CartPageProps> = ({ setCurrentPage }) => {
  const {
    cart,
    updateQuantity,
    removeFromCart,
    clearCart,
    subtotal,
    deliveryFee,
    total,
    deliveryMethod,
    setDeliveryMethod,
    formatNaira,
    settings,
  } = useCart();

  if (cart.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 sm:py-24 text-center">
        <div className="bg-white rounded-3xl p-8 sm:p-14 border border-stone-200 shadow-sm space-y-6">
          <div className="w-20 h-20 bg-red-50 text-red-700 rounded-3xl flex items-center justify-center mx-auto">
            <ShoppingBag className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-stone-900 font-serif">
              Your Shopping Cart is Empty
            </h1>
            <p className="text-stone-600 text-sm max-w-md mx-auto">
              You haven't selected any Nigerian delicacies yet. Explore our fresh daily menu of Jollof rice, native soups, swallows, and grills.
            </p>
          </div>

          <div>
            <button
              onClick={() => setCurrentPage('menu')}
              className="inline-flex items-center gap-2 bg-red-700 hover:bg-red-800 text-white font-bold py-3.5 px-8 rounded-2xl shadow-md transition-all text-sm"
            >
              <span>Explore Nigerian Menu</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <div className="flex items-center justify-between mb-8 pb-4 border-b border-stone-200">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-red-700">
            Order Review
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-stone-950 font-serif">
            Your Shopping Cart ({cart.reduce((s, i) => s + i.quantity, 0)} items)
          </h1>
        </div>

        <button
          onClick={clearCart}
          className="text-xs font-semibold text-stone-500 hover:text-red-700 flex items-center gap-1.5 transition-colors p-2"
        >
          <Trash2 className="w-4 h-4" />
          <span className="hidden sm:inline">Clear Cart</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Col: Cart Items List */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden divide-y divide-stone-100 shadow-sm">
            {cart.map(({ product, quantity }) => (
              <div key={product.id} className="p-4 sm:p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex items-center gap-4 w-full sm:w-auto">
                  <img
                    src={product.image_url}
                    alt={product.name}
                    className="w-18 h-18 sm:w-20 sm:h-20 rounded-xl object-cover border border-stone-200 shrink-0"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src =
                        'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80';
                    }}
                  />
                  <div>
                    <h3 className="font-bold text-stone-900 font-serif text-base line-clamp-1">
                      {product.name}
                    </h3>
                    <span className="text-xs text-stone-500 block mt-0.5">
                      Unit: {formatNaira(product.price)}
                    </span>
                    <span className="text-xs font-extrabold text-red-700 block sm:hidden mt-1">
                      {formatNaira(product.price * quantity)}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-6 w-full sm:w-auto pt-2 sm:pt-0 border-t sm:border-t-0 border-stone-100">
                  {/* Quantity Controls */}
                  <div className="flex items-center border border-stone-300 rounded-xl bg-stone-50 overflow-hidden">
                    <button
                      onClick={() => updateQuantity(product.id, quantity - 1)}
                      className="p-1.5 hover:bg-stone-200 text-stone-700 transition-colors"
                      title="Decrease quantity"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="px-3 text-xs sm:text-sm font-bold text-stone-900">
                      {quantity}
                    </span>
                    <button
                      onClick={() => updateQuantity(product.id, quantity + 1)}
                      className="p-1.5 hover:bg-stone-200 text-stone-700 transition-colors"
                      title="Increase quantity"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Line Total */}
                  <div className="hidden sm:block text-right min-w-[90px]">
                    <span className="text-base font-extrabold text-stone-900 block">
                      {formatNaira(product.price * quantity)}
                    </span>
                  </div>

                  {/* Delete button */}
                  <button
                    onClick={() => removeFromCart(product.id)}
                    className="p-2 text-stone-400 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors"
                    title="Remove dish"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Delivery Method Choice Card */}
          <div className="bg-white rounded-2xl border border-stone-200 p-6 shadow-sm space-y-4">
            <h3 className="font-bold text-stone-900 font-serif text-base">
              Select Fulfilment Method
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label
                className={`flex items-start gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                  deliveryMethod === 'delivery'
                    ? 'border-red-600 bg-red-50/40 text-stone-900'
                    : 'border-stone-200 hover:border-stone-300 text-stone-700'
                }`}
              >
                <input
                  type="radio"
                  name="deliveryMethod"
                  value="delivery"
                  checked={deliveryMethod === 'delivery'}
                  onChange={() => setDeliveryMethod('delivery')}
                  className="mt-1 text-red-600 focus:ring-red-600"
                />
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2 font-bold text-sm">
                    <Truck className="w-4 h-4 text-red-700" />
                    <span>Doorstep Dispatch ({formatNaira(settings?.delivery_fee || 1500)})</span>
                  </div>
                  <p className="text-xs text-stone-500">
                    Hot thermal bag delivery straight to your home or office address in Lagos.
                  </p>
                </div>
              </label>

              <label
                className={`flex items-start gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                  deliveryMethod === 'pickup'
                    ? 'border-red-600 bg-red-50/40 text-stone-900'
                    : 'border-stone-200 hover:border-stone-300 text-stone-700'
                }`}
              >
                <input
                  type="radio"
                  name="deliveryMethod"
                  value="pickup"
                  checked={deliveryMethod === 'pickup'}
                  onChange={() => setDeliveryMethod('pickup')}
                  className="mt-1 text-red-600 focus:ring-red-600"
                />
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2 font-bold text-sm">
                    <Store className="w-4 h-4 text-red-700" />
                    <span>Self Pickup (FREE)</span>
                  </div>
                  <p className="text-xs text-stone-500">
                    Collect directly from 14 Adeola Odeku St, Victoria Island when ready.
                  </p>
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* Right Col: Order Summary & Checkout CTA */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white rounded-2xl border border-stone-200 p-6 shadow-sm space-y-5 sticky top-28">
            <h3 className="font-bold text-stone-900 font-serif text-lg border-b border-stone-100 pb-3">
              Order Summary
            </h3>

            <div className="space-y-3 text-sm">
              <div className="flex justify-between text-stone-600">
                <span>Dishes Subtotal</span>
                <span className="font-semibold text-stone-900">{formatNaira(subtotal)}</span>
              </div>

              <div className="flex justify-between text-stone-600">
                <span className="flex items-center gap-1">
                  <span>Delivery Fee</span>
                  {deliveryMethod === 'pickup' && (
                    <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded font-bold">
                      FREE
                    </span>
                  )}
                </span>
                <span className="font-semibold text-stone-900">
                  {deliveryMethod === 'delivery' ? formatNaira(deliveryFee) : '₦0'}
                </span>
              </div>

              <div className="pt-3 border-t border-stone-200 flex justify-between items-baseline">
                <div>
                  <span className="text-base font-bold text-stone-900 block font-serif">
                    Estimated Total
                  </span>
                  <span className="text-[11px] text-stone-500">
                    Verified securely on server
                  </span>
                </div>
                <span className="text-2xl font-black text-red-700">
                  {formatNaira(total)}
                </span>
              </div>
            </div>

            <button
              onClick={() => setCurrentPage('checkout')}
              className="w-full bg-red-700 hover:bg-red-800 text-white font-bold py-4 px-6 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 text-sm sm:text-base active:scale-[0.99]"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="space-y-2 pt-2 border-t border-stone-100 text-xs text-stone-500">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Verified Direct Bank Transfer & Online Gateways</span>
              </div>
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Order reference & WhatsApp confirmation provided</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
