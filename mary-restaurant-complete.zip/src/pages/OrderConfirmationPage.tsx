import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Copy, 
  Check, 
  Phone, 
  ArrowRight, 
  Clock, 
  Truck, 
  Building2, 
  CreditCard,
  Printer,
  ShoppingBag
} from 'lucide-react';
import { Order, PageRoute } from '../types';
import { useCart } from '../context/CartContext';

interface OrderConfirmationPageProps {
  order: Order | null;
  setCurrentPage: (page: PageRoute) => void;
}

export const OrderConfirmationPage: React.FC<OrderConfirmationPageProps> = ({
  order,
  setCurrentPage,
}) => {
  const { formatNaira, settings } = useCart();
  const [copiedRef, setCopiedRef] = useState(false);

  if (!order) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center space-y-4">
        <h2 className="text-xl font-bold text-stone-900 font-serif">No Order Selected</h2>
        <p className="text-stone-500 text-sm">Please select items from the menu and complete checkout.</p>
        <button
          onClick={() => setCurrentPage('menu')}
          className="bg-red-700 text-white font-bold py-2.5 px-6 rounded-xl text-sm"
        >
          View Menu
        </button>
      </div>
    );
  }

  const handleCopyOrderNumber = () => {
    navigator.clipboard.writeText(order.order_number);
    setCopiedRef(true);
    setTimeout(() => setCopiedRef(false), 2500);
  };

  const whatsappPhone = settings?.whatsapp_number || '2349024971419';
  const displayPhone = settings?.phone_display || '09024971419';

  // Format WhatsApp order summary message
  const itemsText = order.items
    .map((item) => `• ${item.quantity}x ${item.product_name} (${formatNaira(item.line_total)})`)
    .join('\n');

  const rawMessage = `Hello Mary Restaurant! 🍲

I just submitted an order on your website:
*Order Reference:* ${order.order_number}
*Customer Name:* ${order.customer_name}
*Phone:* ${order.customer_phone}
*Fulfilment:* ${order.delivery_method === 'delivery' ? 'Doorstep Delivery' : 'Pickup'}
${order.delivery_method === 'delivery' ? `*Address:* ${order.delivery_address}` : ''}

*Order Items:*
${itemsText}

*Subtotal:* ${formatNaira(order.subtotal)}
*Delivery Fee:* ${formatNaira(order.delivery_fee)}
*Total Amount:* ${formatNaira(order.total_amount)}
*Payment Method:* ${order.payment_method === 'bank_transfer' ? 'Bank Transfer' : 'Online Payment'}
${order.payment_reference ? `*Payment Ref:* ${order.payment_reference}` : ''}

Kindly confirm that you have received this order!`;

  const whatsappUrl = `https://wa.me/${whatsappPhone}?text=${encodeURIComponent(rawMessage)}`;

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-8">
      {/* Success Badge & Header */}
      <div className="text-center space-y-3">
        <div className="w-16 h-16 sm:w-20 sm:h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
          <CheckCircle2 className="w-10 h-10 sm:w-12 sm:h-12" />
        </div>

        <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">
          Order Successfully Received
        </span>

        <h1 className="text-3xl sm:text-4xl font-black text-stone-950 font-serif">
          Thank You, {order.customer_name}!
        </h1>

        <p className="text-sm sm:text-base text-stone-600 max-w-lg mx-auto">
          Your order has been recorded into our kitchen management system. 
          We are getting your delicious meal ready.
        </p>
      </div>

      {/* Order Reference Box with 1-click Copy */}
      <div className="bg-stone-900 text-white rounded-2xl p-5 sm:p-6 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <span className="block text-xs uppercase tracking-wider text-stone-400">
            Order Reference Number
          </span>
          <span className="text-2xl sm:text-3xl font-mono font-black text-amber-400 tracking-wider">
            {order.order_number}
          </span>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <button
            onClick={handleCopyOrderNumber}
            className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-bold py-2.5 px-4 rounded-xl border border-stone-700 transition-colors"
          >
            {copiedRef ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Copied Reference!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Copy Order #</span>
              </>
            )}
          </button>

          <button
            onClick={() => window.print()}
            className="hidden sm:inline-flex items-center justify-center gap-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-bold py-2.5 px-3 rounded-xl border border-stone-700 transition-colors"
            title="Print Receipt"
          >
            <Printer className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Prominent WhatsApp Send Button */}
      <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white rounded-2xl p-6 shadow-md space-y-4">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h3 className="text-lg font-bold font-serif flex items-center gap-2">
              <Phone className="w-5 h-5 fill-current" />
              <span>Send Order Summary to WhatsApp</span>
            </h3>
            <p className="text-emerald-100 text-xs sm:text-sm mt-1 leading-relaxed">
              Click below to send your complete order breakdown directly to Chef Mary's dispatch line ({displayPhone}).
            </p>
          </div>
        </div>

        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center justify-center gap-2.5 w-full bg-white hover:bg-emerald-50 text-emerald-900 font-extrabold py-3.5 px-6 rounded-xl shadow transition-all text-sm sm:text-base"
        >
          <Phone className="w-5 h-5 text-emerald-600" />
          <span>Click to Send Order to WhatsApp ({displayPhone})</span>
        </a>
      </div>

      {/* Payment & Order Status Card */}
      <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-7 shadow-sm space-y-6">
        <div className="flex items-center justify-between border-b border-stone-100 pb-4">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-red-700" />
            <span className="font-bold text-stone-900 text-base font-serif">
              Order Status & Next Steps
            </span>
          </div>

          <span className="text-xs font-bold uppercase tracking-wider px-3 py-1 bg-amber-100 text-amber-900 rounded-full">
            {order.payment_status === 'paid' ? 'Payment Verified' : 'Pending Payment Verification'}
          </span>
        </div>

        {order.payment_method === 'bank_transfer' && order.payment_status !== 'paid' && (
          <div className="p-4 bg-amber-50/80 border border-amber-200 rounded-xl space-y-2 text-xs sm:text-sm text-amber-900">
            <div className="font-bold flex items-center gap-2 text-amber-950">
              <Building2 className="w-4 h-4 text-amber-700" />
              <span>Bank Transfer Instructions</span>
            </div>
            <p>
              Please transfer <strong className="text-stone-900">{formatNaira(order.total_amount)}</strong> to:
            </p>
            <div className="bg-white p-3 rounded-lg border border-amber-200 space-y-1 font-mono text-xs">
              <p>Bank: <strong>{settings?.bank_name || 'Zenith Bank'}</strong></p>
              <p>Account Name: <strong>{settings?.bank_account_name || 'MARY RESTAURANT ENTERPRISES'}</strong></p>
              <p>Account Number: <strong className="text-red-700">{settings?.bank_account_number || '1018944521'}</strong></p>
            </div>
            <p className="text-[11px] text-amber-800">
              Use reference <strong>{order.order_number}</strong> or your name as transfer remark. 
              Once verified by our administrator, your order will be dispatched immediately.
            </p>
          </div>
        )}

        {/* Breakdown of Ordered Items */}
        <div>
          <h4 className="text-xs font-bold text-stone-500 uppercase tracking-wider mb-3">
            Meals in This Order
          </h4>
          <div className="divide-y divide-stone-100 border border-stone-200 rounded-xl overflow-hidden">
            {order.items.map((item, idx) => (
              <div key={idx} className="p-3.5 flex items-center justify-between text-xs sm:text-sm bg-stone-50/50">
                <div className="space-y-0.5">
                  <span className="font-bold text-stone-900">
                    {item.quantity}x {item.product_name}
                  </span>
                  <span className="block text-[11px] text-stone-500">
                    {formatNaira(item.unit_price)} each
                  </span>
                </div>
                <span className="font-extrabold text-stone-900">
                  {formatNaira(item.line_total)}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Financial breakdown */}
        <div className="space-y-2 text-xs sm:text-sm pt-2 border-t border-stone-100">
          <div className="flex justify-between text-stone-600">
            <span>Subtotal</span>
            <span className="font-semibold text-stone-900">{formatNaira(order.subtotal)}</span>
          </div>

          <div className="flex justify-between text-stone-600">
            <span>Fulfilment ({order.delivery_method === 'delivery' ? 'Doorstep Dispatch' : 'Pickup'})</span>
            <span className="font-semibold text-stone-900">{formatNaira(order.delivery_fee)}</span>
          </div>

          <div className="flex justify-between text-base font-extrabold text-stone-950 pt-2 border-t border-stone-200">
            <span>Total Amount</span>
            <span className="text-red-700">{formatNaira(order.total_amount)}</span>
          </div>
        </div>

        {/* Customer Information summary */}
        <div className="pt-4 border-t border-stone-100 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-stone-600">
          <div>
            <span className="font-bold text-stone-900 block uppercase tracking-wider text-[10px]">Contact Person</span>
            <p className="mt-0.5">{order.customer_name} ({order.customer_phone})</p>
          </div>

          <div>
            <span className="font-bold text-stone-900 block uppercase tracking-wider text-[10px]">Fulfilment Address</span>
            <p className="mt-0.5">{order.delivery_address}</p>
          </div>

          {order.delivery_instructions && (
            <div className="sm:col-span-2">
              <span className="font-bold text-stone-900 block uppercase tracking-wider text-[10px]">Delivery Instructions</span>
              <p className="mt-0.5 italic">{order.delivery_instructions}</p>
            </div>
          )}
        </div>
      </div>

      {/* Navigation Buttons */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4">
        <button
          onClick={() => {
            setCurrentPage('menu');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-stone-900 hover:bg-stone-800 text-white font-bold py-3.5 px-6 rounded-xl transition-colors text-sm"
        >
          <ShoppingBag className="w-4 h-4" />
          <span>Order More Food</span>
        </button>

        <button
          onClick={() => {
            setCurrentPage('home');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="text-xs font-bold text-stone-600 hover:text-red-700 transition-colors"
        >
          Return to Homepage
        </button>
      </div>
    </div>
  );
};
