import React from 'react';
import { ShieldCheck, Lock, Eye, Database, FileText } from 'lucide-react';

export const PrivacyPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 space-y-10">
      {/* Header */}
      <div className="text-center space-y-3">
        <div className="w-12 h-12 bg-red-100 text-red-700 rounded-2xl flex items-center justify-center mx-auto">
          <ShieldCheck className="w-6 h-6" />
        </div>
        <span className="text-xs font-bold uppercase tracking-wider text-red-700">
          Compliance & Trust
        </span>
        <h1 className="text-3xl sm:text-4xl font-black text-stone-950 font-serif">
          Privacy Policy
        </h1>
        <p className="text-xs sm:text-sm text-stone-500">
          Last updated: October 2026 · Compliant with the Nigeria Data Protection Act (NDPA)
        </p>
      </div>

      {/* Main Content */}
      <div className="bg-white rounded-3xl border border-stone-200 p-8 sm:p-12 shadow-sm space-y-8 text-stone-700 text-sm leading-relaxed">
        <section className="space-y-3">
          <h2 className="text-xl font-bold text-stone-900 font-serif flex items-center gap-2">
            <Lock className="w-5 h-5 text-red-700" />
            <span>1. Overview and Commitment</span>
          </h2>
          <p>
            At <strong>MARY RESTAURANT</strong>, we respect your privacy and are committed to safeguarding 
            the personal data you share with us when browsing our menu, placing orders, or contacting our kitchen. 
            This Privacy Policy explains how your information is collected, processed, and protected in 
            compliance with the Nigeria Data Protection Act (NDPA).
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-xl font-bold text-stone-900 font-serif flex items-center gap-2">
            <Eye className="w-5 h-5 text-red-700" />
            <span>2. Information We Collect</span>
          </h2>
          <p>When you place an order or interact with our website, we may collect:</p>
          <ul className="list-disc pl-5 space-y-1.5 text-stone-600">
            <li><strong>Customer Contact Details:</strong> Full name, telephone number (for dispatch communication), and email address (if provided).</li>
            <li><strong>Fulfilment Information:</strong> Delivery address, apartment/house details, and special delivery or dietary instructions.</li>
            <li><strong>Order History:</strong> Food items purchased, order totals, and timestamps.</li>
            <li><strong>Payment Verification Data:</strong> Bank transfer reference numbers and transaction identifiers. We do <em>not</em> store full debit card numbers on our servers; card payments are processed securely through certified PCI-DSS payment gateways (such as Paystack or Flutterwave).</li>
          </ul>
        </section>

        <section className="space-y-3">
          <h2 className="text-xl font-bold text-stone-900 font-serif flex items-center gap-2">
            <Database className="w-5 h-5 text-red-700" />
            <span>3. How We Use Your Data</span>
          </h2>
          <p>We use your personal data strictly for:</p>
          <ul className="list-disc pl-5 space-y-1.5 text-stone-600">
            <li>Processing, preparing, and packaging your food orders accurately.</li>
            <li>Dispatching food via our motorcycle delivery riders and communicating order status.</li>
            <li>Verifying bank transfers and payment confirmation with our restaurant finance administrators.</li>
            <li>Responding to customer support queries and WhatsApp communications.</li>
            <li>Maintaining required legal, accounting, and tax records.</li>
          </ul>
        </section>

        <section className="space-y-3">
          <h2 className="text-xl font-bold text-stone-900 font-serif flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-red-700" />
            <span>4. Data Security & Storage</span>
          </h2>
          <p>
            Your information is stored in secured databases protected by encryption and modern Row Level Security (RLS) 
            policies. Access to customer contact and delivery details is strictly restricted to authorized restaurant 
            administrators and kitchen dispatch staff. We never sell, rent, or trade your personal data to third parties.
          </p>
        </section>

        <section className="space-y-3">
          <h2 className="text-xl font-bold text-stone-900 font-serif flex items-center gap-2">
            <FileText className="w-5 h-5 text-red-700" />
            <span>5. Your Rights as a Data Subject</span>
          </h2>
          <p>
            Under the Nigeria Data Protection Act, you have the right to request access to the personal data we hold about you, 
            request corrections, or request deletion of your information from our order archives, subject to statutory accounting requirements.
          </p>
          <p>
            For privacy inquiries or data requests, please contact our administrative team at{' '}
            <strong className="text-stone-900">privacy@maryrestaurant.ng</strong> or call <strong>09024971419</strong>.
          </p>
        </section>
      </div>
    </div>
  );
};
