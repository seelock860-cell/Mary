import os
import zipfile

def create_project_zip():
    output_path = os.path.abspath("public/mary-restaurant-complete.zip")
    root_dir = os.path.abspath(".")
    
    exclude_dirs = {
        "node_modules",
        ".git",
        "dist",
        ".cache",
        "__pycache__"
    }
    
    exclude_files = {
        "mary-restaurant-complete.zip",
        "bun.lock"
    }

    print(f"Packaging project from {root_dir} into {output_path}...")
    
    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(root_dir):
            # Prune excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith(".")]
            
            for file in files:
                if file in exclude_files or file.endswith(".zip") or file.startswith("."):
                    continue
                
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, root_dir)
                zipf.write(full_path, rel_path)
                print(f"Added: {rel_path}")

    size_kb = os.path.getsize(output_path) / 1024
    print(f"Successfully generated {output_path} ({size_kb:.2f} KB)")

if __name__ == "__main__":
    create_project_zip()
