# MARY RESTAURANT - Complete Nigerian Restaurant Website

A modern, responsive, full-stack Nigerian restaurant website built with React, Vite, Tailwind CSS, Express, and Supabase integration, ready for instant deployment on Vercel or any Node.js hosting platform.

---

## 🍽️ Features

- **Brand Identity**: Authentic crimson red and deep charcoal styling, warm cream backgrounds, Playfair Display typography.
- **Full Nigerian Menu**: Party Jollof Rice, Nigerian Fried Rice, White Rice & Buka Stew, Ewa Aganyin & Dodo, Egusi Soup with Pounded Yam, Ogbono Soup with Eba, Fisherman Okra Soup with Fufu, Efo Riro, Amala with Abula, Flame-Grilled Chicken, Crispy Peppered Chicken, Steamed Moi Moi, Dodo, and chilled Nigerian Chapman.
- **Dynamic Food Details**: High-resolution dish photos, ingredients, portion controls, and direct WhatsApp inquiries.
- **Shopping Cart & Checkout**:
  - Doorstep Delivery (flat ₦1,500) or Self Pickup (Free).
  - Nigerian phone number format validation (`080...`, `090...`).
  - **Direct Bank Transfer**: Displays Zenith Bank Account `1018944521` (`MARY RESTAURANT ENTERPRISES`) with 1-click account copy and payment reference note.
  - **Online Payment**: Paystack / card / USSD simulation and verification.
- **Order Reference & WhatsApp Transmission**:
  - Automatically generates unique order reference numbers (e.g. `MR-2026-XXXX`).
  - **1-Click WhatsApp Send Button**: Pre-formats the entire order breakdown and opens WhatsApp to `09024971419` (`2349024971419`).
- **Administrator Dashboard**:
  - Metrics: Total Orders, Pending Orders, In-Kitchen, Completed, and Total Verified Sales in Naira.
  - Order status updater and 1-click **Bank Transfer Payment Verification**.
  - Food Menu CRUD: Add, edit, delete dishes, toggle stock availability, select curated food photos.
  - Storefront settings & Supabase database integration.
- **Supabase Integration**:
  - Full PostgreSQL schema in `/supabase/schema.sql` with Row Level Security (RLS) policies for `profiles`, `categories`, `products`, `orders`, `order_items`, `payments`, and `restaurant_settings`.

---

## 🚀 Quick Start (Local Development)

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Start the development server**:
   ```bash
   npm run dev
   ```
   Open `http://localhost:3000` in your browser.

3. **Build for production**:
   ```bash
   npm run build
   ```

---

## ☁️ Deploying to Vercel

This repository includes a pre-configured `vercel.json` and `/api/index.ts` serverless handler:

1. Import this repository into [Vercel](https://vercel.com).
2. Vercel will automatically detect `vercel.json` with:
   - **Framework Preset**: Vite
   - **Build Command**: `vite build`
   - **Output Directory**: `dist`
3. Click **Deploy**.
4. Your website will be live at `https://your-project.vercel.app` with zero 404 errors!

---

## 🔐 Administrator Login Credentials

- **URL**: Navigate to `/admin-login` or tap the Shield icon in the top header.
- **Username**: `Mary`
- **Default Password**: `Mary124`

---

## 📞 Kitchen & Dispatch Contact

- **WhatsApp**: `09024971419` (`+2349024971419`)
- **Address**: 14 Adeola Odeku Street, Victoria Island, Lagos, Nigeria
- **Hours**: Monday - Sunday: 8:00 AM - 10:00 PM
